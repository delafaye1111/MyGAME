package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.net.URL;

import entity.Entity;
import entity.Player;
import object.SuperObject;
import tile.TileManager;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class GamePanel extends JPanel implements Runnable{
	
	//SCREEN SETTINGS
	final int originalTileSize = 16; // 16x16 tile
	final int scale = 6;
	TileManager tileManager;
	public final int tileSize = originalTileSize * scale; // 96 x 96 tile;
	public final int maxScreenCol = 12;
	public final int maxScreenRow = 12;
	public final int screenWidth = tileSize * maxScreenCol; // 768 pixels
	public final int screenHeight = tileSize * maxScreenRow; // 576 pixels
	URL imageURL = this.getClass().getResource("/maps/awesomeCavePixelArt.png");
	Image backgroundImage = new ImageIcon(imageURL).getImage();
	//WORLD SETTINGS
	public final int maxWorldCol = 50;
	public final int maxWorldRow = 50;
	public final int worldWidth = tileSize * maxWorldCol;
	public final int worldHeigh = tileSize * maxWorldRow;
	// FPS
	int FPS = 60; 
	
	// GAME STATE
	public int gameState;
	public final int titleState = 0;
	public final int playState = 1;
	public final int gameOverState = 2;
	public final int gameWinState = 3;
	// SYSTEM
	TileManager tileM = new TileManager(this);
	KeyHandler keyH = new KeyHandler(this);
	Graphics2D g2;
	
	
	public CollisionChecker cChecker = new CollisionChecker(this); 
	public AssetSetter aSetter = new AssetSetter(this,tileM);
	public UI ui = new UI(this);
	
	String soundFilePath = "/sound/Goblins_Den_(Regular).wav";
	Sound sound = new Sound(soundFilePath);
	Thread gameThread;
	// OBJECT AND ENTITY
	public Player player = new Player(this,keyH,ui);
	public SuperObject obj[] = new SuperObject[10];
	public Entity npc[] = new Entity[10];
	
	public GamePanel() {
		
		this.setPreferredSize(new Dimension(screenWidth,screenHeight));
		this.setBackground(Color.black);
		tileManager = new TileManager(this);
		this.setDoubleBuffered(true);
		this.addKeyListener(keyH);
		this.setFocusable(true);
	}

	public void setupGame() {
		
		aSetter.setObject();
		aSetter.setNPC();
		gameState = titleState;
		sound.play();
		ui.playTime = 30;
		
		
		
	}
	
	public void startGameThread() {
		
		gameThread = new Thread(this);
		gameThread.start();
		
		
	}
	@Override
	public void run() {
		
		
		double drawInterval = 1000000000/FPS; // 0.01666 seconds
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;
		long timer = 0;
		long drawCount = 0;
	
		while(gameThread != null) {
			
			currentTime = System.nanoTime();
			
			delta += (currentTime - lastTime) / drawInterval;
			timer += (currentTime - lastTime);
			lastTime = currentTime;
			
			if(delta >= 1) {
				update();
				repaint();
				delta--;
				drawCount++;
			}
			if(timer >= 1000000000) {
				//System.out.println("FPS:"+drawCount);
				drawCount = 0;
				timer = 0;
			}
		}
	}
	public TileManager getTileManager() {
	    return tileManager;
	}
	public void retry() {
		
		player.setDefaultPositions();
		ui.playTime = 30;
		player.hasSword = 0;
		aSetter.setNPC();
		tileM.loadMap();
		aSetter.setObject();
		sound.stop();
		sound.play();
	}
	public void update() {
		
		// PLAYER
		player.update();
		// NPC
		for(int i = 0 ; i < npc.length; i++) {
			if(npc[i] != null) {
				npc[i].update();
			}
		}
	}
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		
		// TITLE SCREEN
		if(gameState == titleState) {
			
			ui.draw(g2);
		}
		else if(gameState == playState) {
			
			g.drawImage(backgroundImage,0,0,worldWidth,worldHeigh,this);
			
			// TILE
			tileM.draw(g2);
			
			// OBJECT
			for(int i = 0; i< obj.length; i++) {
				if(obj[i] != null) {
					obj[i].draw(g2, this);
				}	
			}
			// NPC
			for(int i = 0; i < npc.length; i++) {
				if(npc[i] != null) {
					npc[i].draw(g2);
				}
			}
			
			//PLAYER
			player.draw(g2);
			if (ui.playTime < 10) {
			    g2.setColor(Color.black);
			    g2.fillRect(0, 0, screenWidth, screenHeight);
			}

			
			
			// UI
			ui.draw(g2);
			g2.dispose();
			
		}
		else if(gameState == gameOverState) {
			ui.draw(g2);
			sound.stop();
		}
		else if(gameState == gameWinState) {
			ui.draw(g2);
			sound.stop();
		}
		}
		// OTHERS
}

