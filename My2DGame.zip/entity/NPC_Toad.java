package entity;

import java.util.Random;

import main.GamePanel;

public class NPC_Toad extends Entity{
	
	public NPC_Toad(GamePanel gp) {
		super(gp);
		
		direction = "down";
		speed = 5 ;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		
		getImage();
	}
public void getImage() {
		
		left1 = setup("/npc/left0");
		left2 = setup("/npc/left1");
		left3 = setup("/npc/left2");
		left4 = setup("/npc/left3");
		right1 = setup("/npc/right0");
		right2 = setup("/npc/right1");
		right3 = setup("/npc/right2");
		right4 = setup("/npc/right3");	
	}
	public void setAction() {
		
		actionLockCounter ++;
		if(actionLockCounter == 120) {
			Random random = new Random();
			int i = random.nextInt(100)+1;
			
			if(i <= 25) {
				direction = "up";
			}
			if(i > 25 && i <=50 ) {
				direction = "down";
			}
			if(i > 50 && i <=75) {
				direction = "left";
			}
			if(i >75 && i <= 100) {
				direction = "right";
			}
			
			actionLockCounter = 0;
		}
	
	}
}
