package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import entity.NPC_Toad;
import object.OBJ_Sword;
import tile.TileManager;

public class AssetSetter {

	GamePanel gp;
	Random random;
	TileManager TileM;
	public int swordsSpawned;
	public int map[][];
	
	
	public AssetSetter(GamePanel gp,TileManager TileM) {
		this.gp = gp;
		random = new Random();
		this.map = TileM.mapTileNum;
	}
	
	public void setObject() {
	    swordsSpawned = 0;
	    List<Integer> occupiedPositions = new ArrayList<>();

	    for (int i = 0; i < gp.obj.length && swordsSpawned < 5; i++) {
	        int worldX, worldY;

	        do {
	            // Generate random coordinates within the game world
	            worldX = random.nextInt(gp.maxScreenCol) * gp.tileSize;
	            worldY = random.nextInt(gp.maxScreenRow) * gp.tileSize;
	        } while (map[worldX / gp.tileSize][worldY / gp.tileSize] == 2 || occupiedPositions.contains(worldX * gp.maxScreenRow + worldY));

	        // Mark the position as occupied
	        occupiedPositions.add(worldX * gp.maxScreenRow + worldY);

	        gp.obj[i] = new OBJ_Sword(gp);
	        gp.obj[i].worldX = worldX;
	        gp.obj[i].worldY = worldY;

	        swordsSpawned++;
	    }
	}


	


	public void setNPC() {
		gp.npc[0] = new NPC_Toad(gp);
		gp.npc[0].worldX = gp.tileSize*10;
		gp.npc[0].worldY = gp.tileSize*1;
	}
}
