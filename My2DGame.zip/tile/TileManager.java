package tile;

import java.awt.Graphics2D;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Random;

import javax.imageio.ImageIO;


import main.GamePanel;
import main.UtilityTool;

public class TileManager {

    GamePanel gp;
    public Tile[] tile;
    public int mapTileNum[][];
    String[] mapFiles = {"map01.txt", "map02.txt", "map03.txt"};
    Random random = new Random();
    
    public TileManager(GamePanel gp) {
        this.gp = gp;
        tile = new Tile[10];
        mapTileNum = new int[gp.maxScreenCol][gp.maxScreenRow];
        getTileImage();
        loadMap();
    }

    public void getTileImage() {

            setup(0,"black16x16",false);
            setup(1,"white16x16",false);
            setup(2,"rock_in_water_01",true);
    }
    
    public void setup(int index, String imageName, boolean collision) {
    	
    	UtilityTool uTool = new UtilityTool();
    	
    	try {
    		tile[index] = new Tile();
    		tile[index].image = ImageIO.read(getClass().getResourceAsStream("/tiles/"+imageName+".png"));
    		tile[index].image = uTool.scaleImage(tile[index].image,gp.tileSize,gp.tileSize);
    		tile[index].collision = collision;
    		
    	}catch(IOException e) {
    		e.printStackTrace();
    	}
    }
    public void loadMap() {
        try {
        	
        	int randomIndex = random.nextInt(mapFiles.length);
        	String selectedMapFile = mapFiles[randomIndex];
        	InputStream is = getClass().getResourceAsStream("/maps/" + selectedMapFile);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            int worldCol = 0;
            int worldRow = 0;

            while (worldCol < gp.maxScreenCol && worldRow < gp.maxScreenRow) {
                String line = br.readLine();

                while (worldCol < gp.maxScreenCol) {
                    String numbers[] = line.split(" ");
                    int num = Integer.parseInt(numbers[worldCol]);
                    mapTileNum[worldCol][worldRow] = num;
                    worldCol++;
                }

                if (worldCol == gp.maxScreenCol) {
                    worldCol = 0;
                    worldRow++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void draw(Graphics2D g2) {
        // Check if the map has been generated, and if not, generate it

        int worldCol = 0;
        int worldRow = 0;

        while (worldCol < gp.maxScreenCol && worldRow < gp.maxScreenRow) {
            int tileNum = mapTileNum[worldCol][worldRow];

            int worldX = worldCol * gp.tileSize;
            int worldY = worldRow * gp.tileSize;
            int screenX = worldX - gp.player.worldX + gp.player.screenX;
            int screenY = worldY - gp.player.worldY + gp.player.screenY;

            if (worldX + gp.tileSize > gp.player.worldX - gp.player.screenX
                    && worldX - gp.tileSize < gp.player.worldX + gp.player.screenX
                    && worldY + gp.tileSize > gp.player.worldY - gp.player.screenY
                    && worldY - gp.tileSize < gp.player.worldY + gp.player.screenY) {
                if (mapTileNum[worldCol][worldRow] == 2) { 
                    // Draw a rock tile
                    g2.drawImage(tile[2].image, screenX, screenY, null);
                } else {
                    // Draw regular tiles (white or black)
                    g2.drawImage(tile[tileNum].image, screenX, screenY, null);
                    
                }
            }

            worldCol++;

            if (worldCol == gp.maxScreenCol) {
                worldCol = 0;
                worldRow++;
            }
        }

    }
  }

  