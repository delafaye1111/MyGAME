package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.text.DecimalFormat;

import javax.swing.ImageIcon;

import object.OBJ_Sword;

public class UI {

	GamePanel gp;
	Graphics2D g2;
	Font arial_40;
	BufferedImage swordImage;
	URL imageURL = this.getClass().getResource("/maps/awesomeCavePixelArt.png");
	Image backgroundImage = new ImageIcon(imageURL).getImage();
	public boolean gameFinishedWin = false;
	public boolean gameFinishedLose = false;
	public double playTime = 30;
	DecimalFormat dFormat = new DecimalFormat("#0.00");
	public int commandNum = 0;
	
	public UI(GamePanel gp) {
		this.gp = gp;
		
		arial_40 = new Font("Arial", Font.PLAIN , 40);
		OBJ_Sword sword = new OBJ_Sword(gp);
		swordImage = sword.image;
	}
	
	public void draw(Graphics2D g2) {
		
		this.g2 = g2;
		if(gp.gameState == gp.titleState) {
			drawTitleScreen();
		}
		else if(gp.gameState == gp.playState){
			g2.setFont(arial_40);
			g2.setColor(Color.white);
			g2.drawImage(swordImage,gp.tileSize/2,gp.tileSize/2,gp.tileSize,gp.tileSize,null);
			g2.drawString("x "+gp.player.hasSword, 135 , 100);
			
			//TIME
			playTime -=(double)1/60;
			if(playTime <= 0) {
				playTime = 0;
				gameFinishedLose = true;
			}
			g2.drawString("Time:"+dFormat.format(playTime), gp.tileSize*9, 100);
		}
		if(gp.gameState == gp.gameOverState) {
			g2.drawImage(backgroundImage, 0, 0, gp.screenWidth,gp.screenHeight, null);
			g2.setFont(arial_40);
			g2.setColor(Color.white);
			String text;
			int textLength;
			int x;
			int y;
			g2.setFont(g2.getFont().deriveFont(Font.BOLD,96F));
			text = "Game Over";
			textLength = (int)g2.getFontMetrics().getStringBounds(text , g2).getWidth();
			x = gp.screenWidth/2 - textLength/2;
			y = gp.screenHeight/2 - (gp.tileSize*3);
			g2.setColor(Color.black);
			g2.drawString(text,x,y);
			g2.setColor(Color.white);
			g2.drawString(text, x-4, y-4);
			// Toad IMAGE
			x = gp.screenWidth/2 - (gp.tileSize*2)/2;
			y += gp.tileSize*2;
			g2.drawImage(gp.npc[0].right1, x, y,gp.tileSize*2,gp.tileSize*2,null);
			// Retry
			g2.setFont(g2.getFont().deriveFont(Font.BOLD,48F));
			text = "Retry";
			x = getXforCenteredText(text);
			y += gp.tileSize*3;
			g2.drawString(text, x, y);
			if(commandNum == 0) {
				g2.drawString(">", x-40, y);
			}
			
			// Quit
			g2.setFont(g2.getFont().deriveFont(Font.BOLD,48F));
			text = "Quit";
			x = getXforCenteredText(text);
			y += gp.tileSize*1;
			g2.drawString(text, x, y);
			if(commandNum == 1) {
				g2.drawString(">", x-40, y);
			}
			//gp.gameThread = null;
		}
		else if(gp.gameState == gp.gameWinState) {
			g2.drawImage(backgroundImage, 0, 0, gp.screenWidth,gp.screenHeight, null);
			g2.setFont(arial_40);
			g2.setColor(Color.white);
			gp.gameState = gp.gameWinState;
			String text;
			int textLength;
			int x;
			int y;
			g2.setFont(g2.getFont().deriveFont(Font.BOLD,96F));
			text = "You Win";
			textLength = (int)g2.getFontMetrics().getStringBounds(text , g2).getWidth();
			x = gp.screenWidth/2 - textLength/2;
			y = gp.screenHeight/2 - (gp.tileSize*3);
			g2.setColor(Color.black);
			g2.drawString(text,x,y);
			g2.setColor(Color.white);
			g2.drawString(text, x-4, y-4);
			// Player Image
			x = gp.screenWidth/2 - (gp.tileSize*2)/2;
			y += gp.tileSize*2;
			g2.drawImage(gp.player.down1, x, y,gp.tileSize*2,gp.tileSize*2,null);
			// Retry
			g2.setFont(g2.getFont().deriveFont(Font.BOLD,48F));
			text = "Retry";
			x = getXforCenteredText(text);
			y += gp.tileSize*3;
			g2.drawString(text, x, y);
			if(commandNum == 0) {
				g2.drawString(">", x-40, y);
			}
			
			// Quit
			g2.setFont(g2.getFont().deriveFont(Font.BOLD,48F));
			text = "Quit";
			x = getXforCenteredText(text);
			y += gp.tileSize*1;
			g2.drawString(text, x, y);
			if(commandNum == 1) {
				g2.drawString(">", x-40, y);
			}
		}
//		else {
//			g2.setFont(arial_40);
//			g2.setColor(Color.white);
//			g2.drawImage(swordImage,gp.tileSize/2,gp.tileSize/2,gp.tileSize,gp.tileSize,null);
//			g2.drawString("x "+gp.player.hasSword, 135 , 100);
//			
//			//TIME
//			playTime -=(double)1/60;
//			if(playTime <= 0) {
//				playTime = 0;
//				gameFinishedLose = true;
//			}
//			g2.drawString("Time:"+dFormat.format(playTime), gp.tileSize*9, 100);
//		}
		
	}
	public void drawTitleScreen() {
			
			g2.drawImage(backgroundImage, 0, 0, gp.screenWidth,gp.screenHeight, null);
			// TITLE NAME
			g2.setFont(g2.getFont().deriveFont(Font.BOLD,96F));
			String text = "Light Out";
			int x = getXforCenteredText(text);
			int y = gp.tileSize*2;
			
			// SHADOW
			g2.setColor(Color.gray);
			g2.drawString(text, x+5, y+5);
			// MAIN COLOR
			g2.setColor(Color.white);
			g2.drawString(text, x, y);
			
			// MENU
			
			g2.setFont(g2.getFont().deriveFont(Font.BOLD,48F));
			text = "NEW GAME";
			x = getXforCenteredText(text);
			y += gp.tileSize*3.5;
			g2.drawString(text, x, y);
			g2.setFont(g2.getFont().deriveFont(Font.BOLD,48F));
			if(commandNum == 0) {
				g2.drawString(">", x-gp.tileSize, y);
			}
			
			text = "QUIT";
			x = getXforCenteredText(text);
			y += gp.tileSize;
			g2.drawString(text, x, y);
			if(commandNum == 1) {
				g2.drawString(">", x-gp.tileSize, y);
			}
		}
	public int getXforCenteredText(String text) {
		
		int length = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth();
		int x = gp.screenWidth/2 - length/2;
		
		return x;
	}
}
