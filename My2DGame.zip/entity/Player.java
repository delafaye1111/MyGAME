package entity;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import main.GamePanel;
import main.KeyHandler;
import main.Sound;
import main.UI;

public class Player extends Entity{
	

	KeyHandler keyH;
	public final int screenX;
	public final int screenY;
	public int hasSword = 0;
	Sound sound = new Sound("/sound/16_human_walk_stone_1.wav");
	Sound sound1 = new Sound("/sound/26_sword_hit_1.wav");
	Sound sound2 = new Sound("/sound/14_human_death_spin.wav");
	Sound sound3 = new Sound("/sound/24_orc_death_spin.wav");
	UI ui;
	public Player(GamePanel gp , KeyHandler keyH,UI ui) {
		
		
		super(gp);
		this.gp = gp;
		this.keyH = keyH;
		this.ui = ui;
		
		
		screenX = gp.screenWidth/2 - (gp.tileSize/2);
		screenY = gp.screenHeight/2 - (gp.tileSize/2);
		
		solidArea = new Rectangle();
		solidArea.x = 32;
		solidArea.y = 72;
		solidArea.width = 32;
		solidArea.height = 12;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		
		
		setDefaultValues();
		getPlayerImage();
	}
	public void setDefaultValues() {

		worldX = gp.tileSize*1;
		worldY = gp.tileSize*10;
		speed = 4;
		direction = "down";
	}
	public void getPlayerImage() {
		
		die1 = setup("/player/die_1");
		die2 = setup("/player/die_2");
		die3 = setup("/player/die_3");
		up1 = setup("/player/walkup_1");
		up2 = setup("/player/walkup_2");
		up3 = setup("/player/walkup_3");
		up4 = setup("/player/walkup_4");
		up5 = setup("/player/walkup_5");
		up6 = setup("/player/walkup_6");
		down1 = setup("/player/walkdown_1");
		down2 = setup("/player/walkdown_2");
		down3 = setup("/player/walkdown_3");
		down4 = setup("/player/walkdown_4");
		down5 = setup("/player/walkdown_5");
		down6 = setup("/player/walkdown_6");
		left1 = setup("/player/walkleft_1");
		left2 = setup("/player/walkleft_2");
		left3 = setup("/player/walkleft_3");
		left4 = setup("/player/walkleft_4");
		left5 = setup("/player/walkleft_5");
		left6 = setup("/player/walkleft_6");
		right1 = setup("/player/walkright_1");
		right2 = setup("/player/walkright_2");
		right3 = setup("/player/walkright_3");
		right4 = setup("/player/walkright_4");
		right5 = setup("/player/walkright_5");
		right6 = setup("/player/walkright_6");
		
	}
	
	public void update() {
		
		if(keyH.upPressed == true || keyH.downPressed == true 
				|| keyH.leftPressed == true || keyH.rightPressed == true) {
			if(keyH.upPressed == true) {
				direction = "up";
			}
			else if(keyH.downPressed == true) {
				direction = "down";
				
			}
			else if(keyH.leftPressed == true) {
				direction = "left";
				
			}
			else if(keyH.rightPressed == true) {
				direction = "right";
				
			}
			
			
			// CHECK TILE COLLISION
			collisionOn = false;
			gp.cChecker.checkTile(this);
			
			// CHECK OBJECT COLLISION
			int objIndex = gp.cChecker.checkObject(this, true);
			pickUpObject(objIndex);
			
			// CHECK NPC COLLISION
			int npcIndex = gp.cChecker.checkEntity(this, gp.npc);
			interactNPC(npcIndex);
			// IF COLLISION IS FALSE, PLAYER CAN MOVE
			if(collisionOn == false) {
				
				switch(direction) {
				case "up":
					worldY -= speed;
					break;
				case "down":
					worldY += speed;
					break;
				case "left":
					worldX -= speed;
					break;
				case "right":
					worldX += speed;
					break;
				}
			}
			spriteCounter++;
			if(spriteCounter > 12) {
				if(spriteNum == 1) {
					spriteNum = 2;
					//sound.play();
				}
				else if(spriteNum == 2) {
					spriteNum = 3;
					//sound.play();
				}
				else if(spriteNum == 3) {
					spriteNum = 4;
					sound.play();
				}
				else if(spriteNum == 4) {
					spriteNum = 5;
					//sound.play();
				}
				else if(spriteNum == 5) {
					spriteNum = 6;
					//sound.play();
				}
				else if(spriteNum == 6) {
					spriteNum = 1;
					sound.play();
				}
				spriteCounter = 0;
			}
		}
	}
		
		
	
	public void pickUpObject(int i) {
		
		if(i != 999) {
			
			String objectName = gp.obj[i].name;
			switch(objectName) {
			case "Sword":
				sound1.play();
				hasSword++;
				ui.playTime += 5;
				gp.obj[i] = null;
				System.out.println("Sword "+hasSword);
				break;
			}
		}
	}
	
	public void setDefaultPositions() {
		worldX = gp.tileSize*1;
		worldY = gp.tileSize*10;
		direction = "down";	
	}
	public void interactNPC(int i) {
		
		if(i != 999 && hasSword < 5 ) {
			gp.gameState = gp.gameOverState;
			sound2.play();
		}
		else if(i != 999 && hasSword == 5) {
			gp.gameState = gp.gameWinState;
			sound3.play();
		}
	}
	
	public void draw(Graphics2D g2) {
		
//		g2.setColor(Color.white);		
//		g2.fillRect(x , y , gp.tileSize, gp.tileSize);
		
		BufferedImage image = null;
		
		switch(direction) {
		case "up":
			if(spriteNum == 1) {
				image = up1;
			}
			if(spriteNum == 2) {
				image = up2;
			}
			if(spriteNum == 3) {
				image = up3;
			}
			if(spriteNum == 4) {
				image = up4;
			}
			if(spriteNum == 5) {
				image = up5;
			}
			if(spriteNum == 6) {
				image = up6;
			}
			break;
		case "down":
			if(spriteNum == 1) {
				image = down1;
			}
			if(spriteNum == 2) {
				image = down2;
			}
			if(spriteNum == 3) {
				image = down3;
			}
			if(spriteNum == 4) {
				image = down4;
			}
			if(spriteNum == 5) {
				image = down5;
			}
			if(spriteNum == 6) {
				image = down6;
			}
			break;
		case "left":
			if(spriteNum == 1) {
				image = left1;
			}
			if(spriteNum == 2) {
				image = left2;
			}
			if(spriteNum == 3) {
				image = left3;
			}
			if(spriteNum == 4) {
				image = left4;
			}
			if(spriteNum == 5) {
				image = left5;
			}
			if(spriteNum == 6) {
				image = left6;
			}
			break;
		case "right":
			if(spriteNum == 1) {
				image = right1;
			}
			if(spriteNum == 2) {
				image = right2;
			}
			if(spriteNum == 3) {
				image = right3;
			}
			if(spriteNum == 4) {
				image = right4;
			}
			if(spriteNum == 5) {
				image = right5;
			}
			if(spriteNum == 6) {
				image = right6;
			}
			break;
		}
		g2.drawImage(image, screenX, screenY,null);
	}
}
